﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace telegrambot
{
    class Program
    {
        private static readonly Telegram.Bot.TelegramBotClient t = new Telegram.Bot.TelegramBotClient("722205007:AAENB8NIWgRedoNHT3MFADGvej0_ngKSC80");
        private static readonly MD5CryptoServiceProvider m = new MD5CryptoServiceProvider();
        private static readonly SHA1CryptoServiceProvider s = new SHA1CryptoServiceProvider();
        private static readonly SHA256CryptoServiceProvider s256 = new SHA256CryptoServiceProvider();
        private static readonly SHA384CryptoServiceProvider s384 = new SHA384CryptoServiceProvider();
        private static readonly SHA512CryptoServiceProvider s512 = new SHA512CryptoServiceProvider();
        private static readonly UTF8Encoding u = new UTF8Encoding();
        private static String md5 = "";
        private static String sha1 = "";
        private static String sha2 = "";
        private static String sha3 = "";
        private static String sha5 = "";


        static void Main(string[] args)
        {
            t.OnMessage += T_OnMessage;
            t.StartReceiving();
            Console.ReadLine();
            t.StopReceiving();
        }

        private static void T_OnMessage(object sender, Telegram.Bot.Args.MessageEventArgs e)
        {
            if (e.Message.Type == Telegram.Bot.Types.Enums.MessageType.Text)
                Console.WriteLine(e.Message.Text);

            
            md5 = BitConverter.ToString(m.ComputeHash(u.GetBytes(e.Message.Text)));
            sha1 = BitConverter.ToString(s.ComputeHash(u.GetBytes(e.Message.Text)));
            sha2 = BitConverter.ToString(s256.ComputeHash(u.GetBytes(e.Message.Text)));
            sha3 = BitConverter.ToString(s384.ComputeHash(u.GetBytes(e.Message.Text)));
            sha5 = BitConverter.ToString(s512.ComputeHash(u.GetBytes(e.Message.Text)));
           
            Console.WriteLine(md5);
            Console.WriteLine(sha1);
            Console.WriteLine(sha2);
            Console.WriteLine(sha3);
            Console.WriteLine(sha5);

            t.SendTextMessageAsync(e.Message.Chat, md5);
            t.SendTextMessageAsync(e.Message.Chat, sha1);
            t.SendTextMessageAsync(e.Message.Chat, sha2);
            t.SendTextMessageAsync(e.Message.Chat, sha3);
            t.SendTextMessageAsync(e.Message.Chat, sha5);
        }
    }
}
